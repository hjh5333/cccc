const puppeteer = require("puppeteer");
const { findElement } = require("./utils/findElement");
const { HomeLogin } = require("./modules/Login");
const config = require("./configs/puppeteerConfig");
const { myProfile , neighborNewPost } = require ("./XpathMap.js");
const { clickElement } = require('./utils/clickElement');

async function startCrawling() {
  const browser = await puppeteer.launch(config);
  const [page] = await browser.pages();
//   console.log("✅ page.constructor.name:", page.constructor.name); // Page
//   console.log("✅ typeof page.$x:", typeof page.$x); // function
let workResult = false;
  try {
    await page.goto("https://www.naver.com/", { waitUntil : "networkidle2"});
    let loginResult = await HomeLogin(page);
    if (loginResult) {
      console.log("✅ 로그인 성공! 버튼 클릭 후 새 탭 감지 시작");
    }

    const newPagePromise = new Promise((resolve) => {
      browser.once('targetcreated', async (target) => {
        const newPage = await target.page();
        await newPage.bringToFront(); // 새 탭 앞으로
        resolve(newPage);             // 새 탭 Page 객체 반환
      });
    });
    
    // 🔹 새 탭을 여는 버튼 클릭 (셀렉터는 네 상황에 맞게 교체!)
    await clickElement(myProfile.profileblogButton, page);
    await clickElement(myProfile.profileblogNewTabButton, page);
    // 🔹 새 탭 객체 가져옴
    const newTab = await newPagePromise;
    
    // 🔹 새 탭에서 작업
    console.log('✅ 새 탭 URL:', newTab.url());
    await newTab.waitForTimeout(1000);

    await clickElement(neighborNewPost.newPostCatalog,newTab);

  } catch (err) {
    console.error("크롤링 실패:", err);
  } finally {
    // await browser.close();
  }
}



module.exports = { startCrawling };
