module.exports = {
    home : {
        homeLoginButton: '//*[contains(@class, "MyView-module__link_login___")]',
    },

    login : {
        userId:'//*[@id="input_item_id"]',
        userPw:'//*[@id="input_item_pw"]',
        submitButton_off_check:'//button[@class="btn_login off next_step nlog-click"]',
        submitButton:'//*[@id="log.login"]',
        
    },

    phoneCertification : {
        phoneTab:'//*[@id="oab.mobile"]',
        phoneInput:'//*[@id="phone_value" and @placeholder="휴대전화 번호"]',
        phoneConfirm:'//input[@type="submit" and @value="확인" and @id="oab.submit"]',
        phoneWrongNumber:'//div[@class="error" and id="error_common]'
    },

    myProfile : { 
        profileLogoutButton:'//*[contains(@class,"MyView-module__btn_logout___")]',
        profileblogButton:'//*[contains(@class,"MyView-module__item_text___") and text()="블로그"]',
        profileblogNewTabButton:'//*[contains(@class,"MyView-module__link_service___")]'
    },

    neighborNewPost : {
        newPostCatalog:'//*[text()="두바이 스탑오버 1박 2일 코스 추천 : 경유가 여행이 되는 하루"]'
    }
    

}