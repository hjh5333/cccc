const findElement = async (xpath, page) => {
  for(let i = 0 ; i <= 3; i++ ){
    try {
      await page.waitForXPath(xpath, { timeout: 5000 });
      const [element] = await page.$x(xpath);
      if (element){
          // console.log(`${xpath} :: Xpath 가 존재합니다.` );
          return element;
      }else{
        return null;
      }
      
    } catch (err) {
      console.error(`XPath 탐색 중 오류 발생: ${xpath}`, err);
      return null;
      }
      }
  };
  
  module.exports = { findElement };
  