const { findElement } = require('./findElement.js');

const writeElement = async (xPath,text,page) => {
    const element = await findElement(xPath,page);
    if(element && typeof element.click === "function"){ 
        await element.type(text,{ delay : 100});
        return true;
    }else{
        console.log(`[ ${xPath} ] 를 찾을 수 없습니다.`);
        return false;
    }
}

module.exports = {writeElement};