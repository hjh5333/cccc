const { clickElement } = require('./clickElement');

// 버튼 클릭 후 새 탭 추적
const [newPage] = await Promise.all([
    new Promise(resolve => 
      browser.once('targetcreated', async target => {
        const page = await target.page();
        await page.bringToFront();
        resolve(page);
      })
    ),
    page.click('버튼의_Selector') // ← 이 버튼 클릭 시 새 탭이 열림
  ]);
  
  // 새 탭에서 원하는 동작 수행
  await newPage.waitForSelector('원하는요소');
  await newPage.click('...');
  