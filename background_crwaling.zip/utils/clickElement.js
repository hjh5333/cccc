const { findElement } = require('./findElement');

const clickElement = async (xPath,page) => {
    const element = await findElement(xPath,page);
    if(element && typeof element.click === "function"){ 
        await element.click();
        return true;
    }else{
        console.log(`[ ${xPath} ] 를 찾을 수 없습니다.`);
        return false;
    }
}

module.exports = {clickElement};