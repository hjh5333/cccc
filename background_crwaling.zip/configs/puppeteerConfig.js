module.exports = {
  headless: false,
  args: [
    "--start-maximized",                       // ✅ 브라우저 자체를 최대화
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--window-size=1920,1080"                  // ✅ 원하는 해상도로 맞추기
  ],
  defaultViewport: null,                       // ✅ 이걸 설정해야 진짜 전체화면 적용됨!
  slowMo: 30
};