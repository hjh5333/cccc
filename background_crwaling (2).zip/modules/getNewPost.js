const { getElement, findElement, delay } = require('../utils/index.js');
const { neighborNewPost } = require ("../XpathMap.js");

const GetNewPost = async (listSelector,innerSelector,page) => {
    try {
        const newPostNum = await getElement(listSelector, innerSelector, page);
        if (newPostNum == [] ){
            console.log('이웃 새 글이 존재하지 않습니다.');
            return newPostNum;
        }else{
            return newPostNum;
        }
        
    }catch(e){
        console.log(e);
        return 0;
    }
}

module.exports = { GetNewPost };