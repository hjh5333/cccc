const { GetNewPost } = require("./getNewPost");
const { HomeLogin } = require("./Login");


module.exports = {
    HomeLogin,
    GetNewPost
};
