const { clickElement } = require( "../utils/clickElement.js");
const { writeElement } = require ("../utils/writeElement.js");
const { delay } = require('../utils/workDelay.js');
const { login , home , phoneCertification , myProfile } = require ("../XpathMap.js");
const { findElement } = require("../utils/findElement.js");

const HomeLogin = async (page) => {
    
    try{
        let findResult = null;
        let clickResult = null;

        // 홈 화면 -> 로그인 창 이동 로직
        await page.waitForXPath(home.homeLoginButton, { timeout: 10000 });
        for( i = 0 ; i <= 3 ; i++){
            clickResult = await clickElement(home.homeLoginButton,page);
            if (clickResult){
                findResult = await findElement(login.userId,page);
                if(findResult){
                    console.log('Home => Login Button Click Complete');
                    break;
                }else{
                    if (i === 3) {
                        throw new Error("❌ 로그인 폼을 찾지 못함."); 
                    }
                    continue;
                }
            }else{
                if (i === 3) {
                    throw new Error("❌ 로그인 버튼 클릭 3회 실패"); 
                }
                console.log('Home => Login Button Click Fail');
                continue;
            }
        }

        // 로그인 작업 및 휴대전화 확인 창 관련 로직
        if(findResult){
            console.log('로그인 폼 창 확인 완료!');
            for( i = 0 ; i <= 3 ; i++){
                await delay(2000);
                await writeElement(login.userId,'hjh5333',page);
                await delay(500);
                await clickElement(login.userPw,page);
                await writeElement(login.userPw,'ghdwjdgus21A@',page);
                await clickElement(login.submitButton,page);
                findResult = await findElement(phoneCertification.phoneTab,page);
                if(findResult){
                    console.log('로그인 완료 => 휴대전화 입력 창 확인됨');
                    await clickElement(phoneCertification.phoneTab,page);
                    await delay(500);
                    await clickElement(phoneCertification.phoneInput,page);
                    await writeElement(phoneCertification.phoneInput,'01090105377',page);
                    await delay(500);
                    await clickElement(phoneCertification.phoneConfirm,page);
                    break;
                }else{
                    console.log("휴대전화 입력 창을 확인하지 못함. 로그인이 정상적으로 완료되었는지 확인...")
                    findResult = await findElement(myProfile.profileLogoutButton,page);
                    if(findResult){
                        console.log('로그인 정상완료');
                        return true;
                    }
                }
            }
        }
        
        findResult = await findElement(myProfile.profileLogoutButton,page);
        if(findResult){
            console.log('로그인 정상완료');
            return true;
        }else{
            console.log('로그인 실패!');
            return false;
        }
        
    }catch(e){
        console.log(e);
        return false;
    }
}

module.exports = { HomeLogin };