const puppeteer = require("puppeteer");

(async () => {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  console.log("typeof page:", typeof page);
  console.log("constructor:", page.constructor.name);
  console.log("typeof page.$x:", typeof page.$x); // 👉 반드시 function 나와야 함

  await browser.close();
})();
