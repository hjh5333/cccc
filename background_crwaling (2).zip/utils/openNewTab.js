const openNewTabAfterClick = async (page, browser, clickAction) => {
    const newPagePromise = new Promise((resolve) => {
      browser.once('targetcreated', async (target) => {
        const newPage = await target.page();
        await newPage.bringToFront();
  
        // 새 탭 안에서 네트워크 요청이 안정적으로 끝나는 걸 기다린다
        try {
          await newPage.waitForNavigation({ waitUntil: 'networkidle2', timeout: 10000 });
          console.log('✅ 새 탭 네비게이션 완료');
        } catch (err) {
          console.warn('⚠️ 새 탭 네비게이션 대기 실패 (네트워크가 2개 이하로 떨어지지 않았을 수도 있음)');
        }
  
        resolve(newPage);
      });
    });
  
    await clickAction();
  
    const newPage = await newPagePromise;
  
    console.log('✅ 새 탭 URL:', newPage.url());
    return newPage;
  };
  
  module.exports = { openNewTabAfterClick };
  