const { clickElement } = require("./clickElement");
const { writeElement } = require("./writeElement");
const { findElement } = require("./findElement");
const { delay } = require("./workDelay");
const { openNewTabAfterClick } = require("./openNewTab");
const { getElement } = require('./getElement');

module.exports = {
  clickElement,
  writeElement,
  findElement,
  delay,
  openNewTabAfterClick,
  getElement
};
