const getElement = async (listSelector, innerSelector, page) => {
    try {
      await page.waitForSelector(listSelector, { timeout: 10000 });
      const items = await page.$$(listSelector);
  
      const results = [];

      console.log(`셀렉터 개수 :: ${items.length}`);

      for (const item of items) {
        const targetHandle = await item.$(innerSelector);
  
        if (targetHandle) {
          try {
            const text = await targetHandle.evaluate(el => el.textContent?.trim());
            console.log('✅ 글 제목:', text);
            if (text) results.push(text);
          } catch (e) {
            console.warn('❌ evaluate 실패:', e.message);
          }
        } else {
          console.log(`❌ [${innerSelector}] 요소를 찾지 못했습니다.`);
        }
      }
  
      return results;
    } catch (err) {
      console.error(`❌ 셀렉터 탐색 중 오류 발생: ${listSelector}`, err);
      return [];
    }
  };
  
module.exports = { getElement };