module.exports = {
  headless: false,                // 브라우저 창 띄우기
  args: [
    "--start-maximized"            // 브라우저를 '최대화' 상태로 시작
  ],
  defaultViewport: null,           // 이거 반드시 null 해야 진짜 브라우저 창 크기 따라감
  slowMo: 1
};
