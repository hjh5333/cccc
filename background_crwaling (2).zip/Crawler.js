
const puppeteer = require("puppeteer");
const config = require("./configs/puppeteerConfig");
const { myProfile , neighborNewPost } = require ("./XpathMap.js");
const { HomeLogin , GetNewPost } = require("./modules/index.js");
const { clickElement, openNewTabAfterClick } = require('./utils/index.js');

async function startCrawling() {
  const browser = await puppeteer.launch(config);
  const [page] = await browser.pages();
//   console.log("✅ page.constructor.name:", page.constructor.name); // Page
//   console.log("✅ typeof page.$x:", typeof page.$x); // function
let workResult = false;
  try {
    await page.goto("https://www.naver.com/", { waitUntil : "networkidle2"});
    let loginResult = await HomeLogin(page);
    if (loginResult) {
      console.log("✅ 로그인 성공! 버튼 클릭 후 새 탭 감지 시작");
    }

    const blogMainPage = await openNewTabAfterClick(
      page,
      browser,
      async () => {
        await clickElement(myProfile.profileblogButton,page);
        await clickElement(myProfile.profileblogNewTabButton,page);
      }
    )

    console.log('이웃 새 글 확인 진행');
    const newTitlesList = await GetNewPost(
      neighborNewPost.newPostList,
      neighborNewPost.newPostTitle,
      blogMainPage
    );
    if ( newTitlesList == []) {
      console.log('이웃 새 글이 존재하지 않습니다! ');
    }else{
      console.log(newTitlesList);
    }
    
    

  } catch (err) {
    console.error("크롤링 실패:", err);
  } finally {
    // await browser.close();
  }
}



module.exports = { startCrawling };
