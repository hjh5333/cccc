const { startCrawling } = require('./Crawler.js');

startCrawling();